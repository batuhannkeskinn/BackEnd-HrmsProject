package kodlama.io.HrmsProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HrmsProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
